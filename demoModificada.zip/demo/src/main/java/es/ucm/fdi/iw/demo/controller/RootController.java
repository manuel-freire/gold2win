package es.ucm.fdi.iw.demo.controller;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller //decir que es controlador, sino no lo reconoce
public class RootController {

    private static Logger log = LogManager.getLogger(
        RootController.class);

    private static final String OBJETIVO = "o";
    private static final String INTENTOS = "i";
    private final Random random = new Random();
    
    @GetMapping("/play") //maneja la ruta /, se ejecuta cada vez que el usuario interactua con el formulario   
    public String index(
    		HttpSession session, /*coger la informacion de la sesion, si son muchas cosas, mejor una BBDD pero solo
			para los intentos no hace falta*/
            Model model, /* model sirve para guardar los datos que el servidor quiere mostrar en la web */
            @RequestParam(required = false) Integer entero) { //me tienen que pasar un entero

    	Integer i = (Integer)session.getAttribute(INTENTOS);
    	Integer o = (Integer)session.getAttribute(OBJETIVO);
		
    	String respuesta = null; //debe coincidir con th:text = "$ {respuesta}" en el html

    	if (o == null || i == -1) {
    		o = random.nextInt(11); // entre 0 y 10, ambos inclusive
    		i = 0; 
			/*
			 * si esto sale feo en una consola de Windows PowerShell, copia y pega esto en la consola:
			 * $OutputEncoding = [Console]::InputEncoding = [Console]::OutputEncoding =
                    New-Object System.Text.UTF8Encoding
			 * (ver https://stackoverflow.com/a/49481797/15472)
			 */
    		respuesta = "he pensado un número del 0 al 10 - ¿lo intentas adivinar?";
    	} else if (entero == null) {
			respuesta = "¿vas a intentar adivinarlo, o qué? - llevas " + i + " intentos.";
    	} else {
    		i ++;
    		if (entero < o) {
				respuesta = "el mío es más grande - y llevas " + i + " intentos.";
    		} else if (entero > o) {
				respuesta =  "el mío es más pequeño - y llevas " + i + " intentos.";
    		} else {
    			respuesta = "¡bingo! ¡era el " + o + "! - has necesitado " + i + " intentos... y ya he pensado en otro";
    			i = 0; // resetea intentos
        		o = random.nextInt(11); // entre 0 y 10, ambos inclusive
    		}
    	}
    	
		session.setAttribute(INTENTOS, i);
		session.setAttribute(OBJETIVO, o);
    	
        log.info("\n -- El usuario dice: '{}'!\n -- Yo respondo '{}'", entero, respuesta); //que es esto?
		model.addAttribute("respuesta", respuesta); // th:text = "$ {respuesta}" en el html
		return "adivina";
	}


	@GetMapping("/") 
	public String home() {
		return "index";
    } 

	@GetMapping("/authors") 
	public String authors() {
		return "authors";
    }


	@GetMapping("/reset") //ruta para resetear el juego (el nombre del metodo realmente da igual??)
	public String reset(HttpSession session) {
		session.setAttribute(INTENTOS, -1);
		session.setAttribute(OBJETIVO, null);
		return "adivina";
    }
}
